from project.beverage.beverage import Beverage

class HotBeverage(Beverage):
    pass

