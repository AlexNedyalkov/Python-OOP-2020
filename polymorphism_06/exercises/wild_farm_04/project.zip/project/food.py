from abc import ABC, abstractmethod

class Food(ABC):

    def __init__(self, quantity):
        self.__quantity = quantity

    @property
    def quantity(self):
        return self.__quantity


class Vegetable(Food):
    pass

class Fruit(Food):
    pass

class Meat(Food):
    pass

class Seed(Food):
    pass